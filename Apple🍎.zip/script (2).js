function showTime() {
	document.getElementById('currentTime').innerHTML = new Date().toUTCString();
}
showTime();
setInterval(function () {
	showTime();
}, 1000);
const grid = document.getElementById("gameGrid");
const log = document.getElementById("log");
const nextRoundBtn = document.getElementById("nextRoundBtn");

let correctIndex = -1;
let round = 0;

// Generate RNG based on local time (hidden to user)
function generateRandomIndex() {
  const currentTime = new Date().getMilliseconds(); // Get the current milliseconds (local timezone)
  return currentTime % 5; // Random between 0 and 4
}

function renderRow(rowNum) {
  const row = [];
  correctIndex = generateRandomIndex(); // Update the RNG per row based on time

  for (let i = 0; i < 5; i++) {
    const div = document.createElement("div");
    div.classList.add("apple");
    div.dataset.index = i;
    div.dataset.row = rowNum;
    div.innerText = "";

    if (i === correctIndex) {
      div.classList.add("hint"); // Show hint visually for testing (remove for production)
    }

    div.onclick = () => {
      if (parseInt(div.dataset.index) === correctIndex) {
        div.classList.add("correct");
        log.innerText = `Correct! Row ${rowNum + 1}, Column ${i + 1}`;
        if (rowNum < 4) {
          nextRoundBtn.style.display = "block"; // Show Next Round button
        }
      } else {
        div.classList.add("wrong");
        log.innerText = `Wrong choice. Game Over at Row ${rowNum + 1}`;
        grid.querySelectorAll(".apple").forEach(el => el.onclick = null);
      }
    };

    row.push(div);
  }
  row.forEach(div => grid.appendChild(div));
}

// Trigger the first row
renderRow(round);

// Handle the Next Round button
nextRoundBtn.onclick = () => {
  round++;
  nextRoundBtn.style.display = "none"; // Hide button for next round
  grid.innerHTML = ""; // Clear the previous row
  renderRow(round); // Render the next row
};
